cat sl_list.txt | ./loader
sh auto_rep.sh