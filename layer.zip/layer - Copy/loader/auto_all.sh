cat *.txt | ./loader
sh auto_all.sh