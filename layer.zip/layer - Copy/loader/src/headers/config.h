#pragma once

#define HTTP_SERVER "143.198.62.191"
#define HTTP_PORT 80

#define TFTP_SERVER "143.198.62.191"
